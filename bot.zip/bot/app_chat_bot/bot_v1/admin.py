# bots/admin.py
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.models import User
from .models import Business, Profile, Conversation, Message

# Define un 'inline' para poder editar el Profile dentro de la vista de User
class ProfileInline(admin.StackedInline):
    model = Profile
    can_delete = False
    verbose_name_plural = 'Perfiles'

# Define un nuevo User admin
class UserAdmin(BaseUserAdmin):
    inlines = (ProfileInline,)

# Vuelve a registrar el User admin con nuestra versión mejorada
admin.site.unregister(User.objects.model)
admin.site.register(User, UserAdmin)

# Registra el nuevo modelo Business
@admin.register(Business)
class BusinessAdmin(admin.ModelAdmin):
    list_display = ('name', 'botpress_bot_id', 'is_active', 'assignment_strategy')
    list_filter = ('is_active', 'assignment_strategy')
    search_fields = ('name',)

# Registra los otros modelos para verlos en el admin
@admin.register(Conversation)
class ConversationAdmin(admin.ModelAdmin):
    list_display = ('user_first_name', 'business', 'status', 'assigned_agent', 'last_message_time')
    list_filter = ('business', 'status')
    search_fields = ('user_first_name', 'user_id')

admin.site.register(Message)

@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'is_online')
    # ¡LA LÍNEA MÁGICA! Activa la doble ventana para el campo 'businesses'
    filter_horizontal = ('businesses',)