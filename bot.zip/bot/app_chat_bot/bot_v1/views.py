# bots/views.py

import json
import requests
import random
from django.http import HttpResponse, Http404
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.template.loader import render_to_string
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync
from django.utils import timezone
from django.db.models import Q
from .models import Business, Conversation, Message, Profile
from django.conf import settings
from django.db.models import Count
from django.db.models.functions import TruncDay

# --- CONFIGURACIÓN ---
# Ya no necesitamos tokens globales aquí, se obtendrán del modelo Business
BOTPRESS_BASE_URL = (
    "http://localhost:3000/api/v1/bots"  # Asumimos Botpress en localhost
)


# ==============================================================================
# VISTA PRINCIPAL DEL WEBHOOK
# ==============================================================================
@csrf_exempt
def telegram_webhook(request, token):  # <-- 1. Recibe el token de la URL
    if request.method != "POST":
        return HttpResponse("Método no permitido.", status=405)

    try:
        # --- 2. IDENTIFICA EL NEGOCIO ---
        # Busca un negocio activo que coincida con el token
        business = get_object_or_404(Business, telegram_token=token, is_active=True)

        update = json.loads(request.body.decode("utf-8"))
        message_data = update.get("message", {})

        user_id = message_data["from"]["id"]
        chat_id = message_data["chat"]["id"]

        # --- 3. PASA EL NEGOCIO A LAS OTRAS FUNCIONES ---
        conversation = get_or_create_conversation(
            user_id, chat_id, message_data, business=business
        )

        if "contact" in message_data:
            handle_contact_message(message_data, conversation)
        elif message_data.get("text"):
            handle_text_message(
                message_data, conversation, business=business
            )  # Pasamos business

    except Http404:
        print(f"Error: Mensaje recibido con un token desconocido o inactivo: {token}")
        return HttpResponse("Token no autorizado.", status=403)
    except (KeyError, json.JSONDecodeError):
        return HttpResponse("❌ Error procesando el mensaje.", status=400)

    return HttpResponse("OK")


# ==============================================================================
# FUNCIONES AUXILIARES PARA EL WEBHOOK (ACTUALIZADAS)
# ==============================================================================
def get_or_create_conversation(
    user_id, chat_id, message_data, business
):  # <-- Recibe business
    user_first_name = message_data["from"].get("first_name", "")

    # --- 4. USA EL PAR (user_id, business) PARA CREAR LA CONVERSACIÓN ---
    conversation, created = Conversation.objects.get_or_create(
        user_id=user_id,
        business=business,  # <-- Clave de la arquitectura Multi-Negocio
        defaults={"chat_id": chat_id, "user_first_name": user_first_name},
    )
    if not created and conversation.chat_id != chat_id:
        conversation.chat_id = chat_id
        conversation.save()
    return conversation


def handle_contact_message(message_data, conversation):
    # ... (Esta función no necesita cambios, ya que opera sobre la conversación) ...
    phone_number = message_data["contact"]["phone_number"]
    conversation.phone_number = phone_number
    # ...


def handle_text_message(message_data, conversation, business):  # <-- Recibe business
    user_message = message_data.get("text", "")
    Message.objects.create(conversation=conversation, sender="USER", text=user_message)

    if conversation.status != "BOT":
        notify_agent_of_new_message(conversation, user_message)
        return

    palabras_clave = ["agente", "humano", "persona", "ayuda"]
    if any(palabra in user_message.lower() for palabra in palabras_clave):
        transfer_to_agent(
            conversation
        )  # <-- transfer_to_agent usará la conversación para encontrar el negocio
        return

    send_to_botpress_and_reply(
        conversation, user_message, business=business
    )  # <-- Pasamos business


def notify_agent_of_new_message(conversation, user_message):
    # ... (Esta función no necesita cambios, usa conversation.business.id) ...
    print(
        f"Notificando al agente ({conversation.assigned_agent}) sobre nuevo mensaje..."
    )
    channel_layer = get_channel_layer()
    group_name = f"business_{conversation.business.id}"  # <-- Ya es Multi-Negocio
    async_to_sync(channel_layer.group_send)(
        group_name,
        {
            "type": "chat_message",
            "message": user_message,
            "sender": "USER",
            "sender_name": conversation.user_first_name,
        },
    )


def transfer_to_agent(conversation):
    # --- 5. LÓGICA DE RULETA MEJORADA Y MULTI-NEGOCIO ---
    if conversation.status != "BOT":
        return

    available_agents = User.objects.filter(
        is_staff=True,
        is_active=True,
        profile__is_online=True,
        profile__businesses=conversation.business,  # <-- Filtra agentes solo de ESE negocio
    ).order_by("profile__last_assignment_time")

    agent_to_assign = available_agents.first()

    if agent_to_assign:
        conversation.status = "PENDING"
        conversation.assigned_agent = agent_to_assign
        conversation.save()
        agent_to_assign.profile.last_assignment_time = timezone.now()
        agent_to_assign.profile.save()
        response_text = f"¡Entendido! Te estoy transfiriendo. Serás atendido por {agent_to_assign.first_name or agent_to_assign.username}."
        print(
            f"🗣️ Conversación {conversation.id} transferida a {agent_to_assign.username} por ruleta."
        )
    else:
        response_text = (
            "Lo siento, no hay agentes disponibles en este momento. Intenta más tarde."
        )

    send_telegram_message(conversation.chat_id, response_text)
    Message.objects.create(conversation=conversation, sender="BOT", text=response_text)

    from .consumers import AgentStatusConsumer

    channel_layer = get_channel_layer()
    html_chat = render_to_string(
        "bots/partials/pending_chat_item.html", {"conv": conversation}
    )
    group_name = f"business_{conversation.business.id}"
    async_to_sync(channel_layer.group_send)(
        group_name, {"type": "new_pending_chat", "html": html_chat}
    )


def send_to_botpress_and_reply(
    conversation, user_message, business
):  # <-- Recibe business
    if not business.botpress_bot_id:
        print(
            f"Error: El negocio '{business.name}' no tiene un Botpress Bot ID configurado."
        )
        return

    print(f"Mensaje para el bot '{business.botpress_bot_id}'. Enviando a Botpress...")
    converse_url = f"{BOTPRESS_BASE_URL}/{business.botpress_bot_id}/converse/{conversation.user_id}"

    try:
        botpress_response = requests.post(
            converse_url, json={"type": "text", "text": user_message}
        )

        # --- PRINTS DE DEPURACIÓN CRÍTICOS ---
        print(f"-> Petición enviada a: {converse_url}")
        print(
            f"<- Botpress respondió con código de estado: {botpress_response.status_code}"
        )
        print(f"<- Contenido de la respuesta de Botpress: {botpress_response.text}")
        # --- FIN DE PRINTS ---

        botpress_response.raise_for_status()
        bot_responses = botpress_response.json().get("responses", [])
    except requests.exceptions.RequestException as e:
        print(f"❌ Error al conectar con Botpress: {e}")
        send_telegram_message(
            conversation.chat_id, "⚠️ El bot no está disponible en este momento."
        )
        return

    if not bot_responses:
        print(
            "-> Django concluye: Botpress no devolvió ninguna respuesta en la lista 'responses'."
        )

    for response in bot_responses:
        if response.get("type") == "text":
            message_text = response.get("text", "")
            if message_text:
                print(f"-> Reenviando respuesta a Telegram: '{message_text}'")
                send_telegram_message(conversation.chat_id, message_text)
                Message.objects.create(
                    conversation=conversation, sender="BOT", text=message_text
                )


def send_telegram_message(chat_id, text, reply_markup=None):
    # Usa settings.TELEGRAM_API_TOKEN en lugar de la variable global
    url = f"https://api.telegram.org/bot{settings.TELEGRAM_API_TOKEN}/sendMessage"
    payload = {"chat_id": chat_id, "text": text}
    if reply_markup:
        payload["reply_markup"] = reply_markup
    try:
        requests.post(url, json=payload).raise_for_status()
    except requests.exceptions.RequestException as e:
        print(f"❌ Error al enviar mensaje a Telegram: {e}")


# ==============================================================================
# VISTAS PARA EL PANEL DE AGENTES (ACTUALIZADAS)
# ==============================================================================
@login_required
def live_chats_view(request):
    # Por defecto, asumimos que es un agente normal
    conversations_queryset = Conversation.objects.none()
    agents_queryset = User.objects.none()

    try:
        if request.user.profile.is_supervisor:
            # El supervisor ve TODAS las conversaciones de sus negocios
            user_businesses = request.user.profile.businesses.all()
            conversations_queryset = Conversation.objects.filter(
                business__in=user_businesses
            )
            agents_queryset = User.objects.filter(
                is_staff=True, profile__businesses__in=user_businesses
            ).distinct()
        else:
            # El agente normal solo ve las conversaciones PENDIENTES y las SUYAS
            user_businesses = request.user.profile.businesses.all()
            conversations_queryset = Conversation.objects.filter(
                business__in=user_businesses
            ).filter(Q(status="PENDING") | Q(assigned_agent=request.user))
            agents_queryset = User.objects.filter(
                is_staff=True, profile__businesses__in=user_businesses
            ).distinct()

    except Profile.DoesNotExist:
        pass  # Maneja el caso de que un usuario no tenga perfil
    pending_conversations_count = conversations_queryset.filter(
        status="PENDING"
    ).count()

    context = {
        "conversations": conversations_queryset.order_by("-last_message_time"),
        "agents": agents_queryset,
        "pending_count": pending_conversations_count,
    }
    return render(request, "bots/live_chats.html", context)

@login_required
def conversation_detail_view(request, user_id):
    # 1. Obtener la conversación
    conversation = get_object_or_404(Conversation, user_id=user_id)
    
    has_profile = hasattr(request.user, 'profile')
    if not request.user.is_superuser:
        if not has_profile or conversation.business not in request.user.profile.businesses.all():
            return HttpResponse("No tienes permiso para ver este chat.", status=403)
        
    if request.method == 'POST':
        message_text = request.POST.get('message_text', '')
        if message_text:
            Message.objects.create(
                conversation=conversation,
                sender='HUMAN',
                text=message_text
            )
            send_telegram_message(conversation.business.telegram_token, conversation.chat_id, message_text)
        
        return redirect('conversation_detail', user_id=user_id)

    messages = conversation.messages.all() 
    
    context = {
        'conversation': conversation, 
        'messages': messages
    }
    
    return render(request, 'bots/conversation_detail.html', context)


@login_required
def close_conversation_view(request, user_id):
    """
    Esta vista cierra la intervención humana y devuelve el control al bot.
    """
    try:
        conversation = Conversation.objects.get(user_id=user_id)
        conversation.status = "BOT"
        conversation.assigned_agent = None
        conversation.save()
        notification_text = "Gracias por contactarnos. Nuestro agente ha finalizado esta sesión. Ahora estás hablando de nuevo con nuestro asistente virtual."
        send_telegram_message(conversation.chat_id, notification_text)
        Message.objects.create(
            conversation=conversation, sender="BOT", text=notification_text
        )
    except Conversation.DoesNotExist:
        pass
    return redirect("live_chats")


@login_required
def claim_conversation_view(request, user_id):

    conversation = get_object_or_404(Conversation, user_id=user_id)

    if conversation.status == "PENDING":
        conversation.status = "HUMAN"
        conversation.assigned_agent = (
            request.user
        )  # ¡Asignamos al agente que hizo la petición!
        conversation.save()

        channel_layer = get_channel_layer()
        group_name = (
            f"business_{conversation.business.id}"  # Notificamos al grupo del negocio
        )
        async_to_sync(channel_layer.group_send)(
            group_name,
            {
                "type": "chat_claimed",
                "user_id": user_id,
            },
        )

        agent_name = request.user.first_name or request.user.username
        notification_text = f"¡Hola! Soy {agent_name} y te atenderé a partir de ahora."
        send_telegram_message(conversation.chat_id, notification_text)
        Message.objects.create(
            conversation=conversation, sender="HUMAN", text=notification_text
        )

    return redirect("conversation_detail", user_id=user_id)


@login_required
def reassign_conversation_view(request, user_id):
    """
    Permite a un supervisor reasignar una conversación a otro agente.
    """
    # 1. Chequeo de Seguridad: Solo los supervisores pueden hacer esto.
    if not hasattr(request.user, "profile") or not request.user.profile.is_supervisor:
        return HttpResponse("No tienes permiso para realizar esta acción.", status=403)

    if request.method == "POST":
        conversation = get_object_or_404(Conversation, user_id=user_id)
        new_agent_id = request.POST.get(
            "agent_id"
        )  # Obtenemos el ID del nuevo agente desde el formulario

        if new_agent_id:
            new_agent = get_object_or_404(User, id=new_agent_id)

            # Guardamos el ID del agente antiguo para notificarlo
            old_agent_id = (
                conversation.assigned_agent.id if conversation.assigned_agent else None
            )

            # 2. Actualizamos la conversación
            conversation.assigned_agent = new_agent
            conversation.status = "HUMAN"  # Nos aseguramos que esté en modo humano
            conversation.save()

            # 3. Notificar en tiempo real del cambio (a futuro se puede implementar)
            print(
                f"SUPERVISOR: Chat {conversation.id} reasignado de {old_agent_id} a {new_agent.id}"
            )

    # 4. Redirigimos al supervisor de vuelta al panel principal
    return redirect("live_chats")


@login_required
def save_notes_view(request, user_id):
    """
    Guarda las notas enviadas desde el formulario del panel de agente.
    Incluye verificación de seguridad multi-negocio.
    """
    conversation = get_object_or_404(Conversation, user_id=user_id)

    # --- CHEQUEO DE SEGURIDAD MULTI-NEGOCIO ---
    # Verificamos que el agente pertenezca al negocio de esta conversación
    if (
        not request.user.is_superuser
        and conversation.business not in request.user.profile.businesses.all()
    ):
        return HttpResponse("No tienes permiso para editar este chat.", status=403)

    if request.method == "POST":
        notes = request.POST.get("notes", "")
        conversation.notes = notes
        conversation.save()

    # Redirige al agente de vuelta al chat
    return redirect("conversation_detail", user_id=user_id)


# bot_v1/views.py


@login_required
def dashboard_view(request):
    """
    Muestra métricas y gráficos filtrados por los negocios del usuario.
    """
    # 1. Filtramos las conversaciones según los permisos del usuario
    if request.user.is_superuser:
        conversations_queryset = Conversation.objects.all()
    else:
        try:
            user_businesses = request.user.profile.businesses.all()
            conversations_queryset = Conversation.objects.filter(
                business__in=user_businesses
            )
        except Profile.DoesNotExist:
            conversations_queryset = Conversation.objects.none()

    # 2. Cálculos de Métricas Generales
    total_conversations = conversations_queryset.count()
    # Filtramos mensajes que pertenecen a las conversaciones permitidas
    total_messages = Message.objects.filter(
        conversation__in=conversations_queryset
    ).count()

    # 3. Datos para Gráficos: Conversaciones por día (últimos 30 días)
    conversations_per_day = (
        conversations_queryset.filter(
            start_time__gte=timezone.now() - timezone.timedelta(days=30)
        )
        .annotate(day=TruncDay("start_time"))
        .values("day")
        .annotate(count=Count("user_id"))
        .order_by("day")
    )

    labels_days = [c["day"].strftime("%d/%m") for c in conversations_per_day]
    data_days = [c["count"] for c in conversations_per_day]

    # 4. Datos para Gráficos: Distribución de Estados
    status_distribution = conversations_queryset.values("status").annotate(
        count=Count("status")
    )
    labels_status = [s["status"] for s in status_distribution]
    data_status = [s["count"] for s in status_distribution]

    context = {
        "total_conversations": total_conversations,
        "total_messages": total_messages,
        "labels_days": json.dumps(labels_days),
        "data_days": json.dumps(data_days),
        "labels_status": json.dumps(labels_status),
        "data_status": json.dumps(data_status),
    }
    return render(request, "bots/dashboard.html", context)
