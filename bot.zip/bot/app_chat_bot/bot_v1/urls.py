# bots/urls.py

from django.urls import path
from . import views

urlpatterns = [
    # Ruta para nuestro webhook original
    path('webhook/<str:token>/', views.telegram_webhook, name='telegram_webhook'),
    
    # Rutas para el Panel de Agentes
    path('live_chats/', views.live_chats_view, name='live_chats'),
    
    # ¡LA RUTA CLAVE! Nos aseguramos de que tenga el name='conversation_detail'
    path('conversation/<int:user_id>/', views.conversation_detail_view, name='conversation_detail'),
    
    path('conversation/<int:user_id>/claim/', views.claim_conversation_view, name='claim_conversation'),
    path('conversation/<int:user_id>/close/', views.close_conversation_view, name='close_conversation'),
    path('conversation/<int:user_id>/save_notes/', views.save_notes_view, name='save_notes'),
    path('conversation/<int:user_id>/reassign/', views.reassign_conversation_view, name='reassign_conversation'),

    path('dashboard/', views.dashboard_view, name='dashboard'),

]