import json
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
# from django.contrib.auth.models import User
from .models import Conversation, Message, Profile
from .views import send_telegram_message

# ==============================================================================
# CONSUMIDOR PARA EL ESTADO ONLINE/OFFLINE DE AGENTES
# ==============================================================================
# bots/consumers.py


# ==============================================================================
# CONSUMIDOR PARA EL ESTADO ONLINE/OFFLINE DE AGENTES
# ==============================================================================
class AgentStatusConsumer(AsyncWebsocketConsumer):
    # Ya no necesitamos un GROUP_NAME global, se creará dinámicamente

    async def connect(self):
        self.user = self.scope["user"]
        if not self.user.is_authenticated or not self.user.is_staff:
            await self.close()
            return

        await self.accept()
        
        # Obtenemos los negocios del agente y lo unimos a cada grupo
        self.business_groups = []
        user_businesses = await self.get_user_businesses()
        for business in user_businesses:
            group_name = f"business_{business.id}"
            self.business_groups.append(group_name)
            await self.channel_layer.group_add(group_name, self.channel_name)
        
        await self.update_and_broadcast_status(True)
        print(f"PRESENCE: Agente '{self.user.username}' está ONLINE.")

    async def disconnect(self, close_code):
        if hasattr(self, 'user') and self.user.is_authenticated:
            await self.update_and_broadcast_status(False)
            # Se sale de todos los grupos de negocio a los que se unió
            if hasattr(self, 'business_groups'):
                for group_name in self.business_groups:
                    await self.channel_layer.group_discard(group_name, self.channel_name)
            print(f"PRESENCE: Agente '{self.user.username}' está OFFLINE.")

    # Esta función se llama cuando llega un mensaje de actualización de estado al grupo
    async def agent_status_update(self, event):
        await self.send(text_data=json.dumps({
            'type': 'status_update',
            'user_id': event['user_id'],
            'is_online': event['is_online']
        }))
    
    # Estas dos funciones son para las notificaciones de la cola de atención en vivo
    async def new_pending_chat(self, event):
        await self.send(text_data=json.dumps({
            'type': 'new_pending_chat',
            'html': event['html']
        }))

    async def chat_claimed(self, event):
        await self.send(text_data=json.dumps({
            'type': 'chat_claimed',
            'user_id': event['user_id']
        }))

    # Función auxiliar para actualizar BD y transmitir el cambio
    async def update_and_broadcast_status(self, status):
        await self.set_online_status(status)
        # Transmite el cambio a todos los grupos de negocio del agente
        if hasattr(self, 'business_groups'):
            for group_name in self.business_groups:
                await self.channel_layer.group_send(
                    group_name,
                    {
                        "type": "agent_status_update",
                        "user_id": self.user.id,
                        "is_online": status,
                    }
                )

    @database_sync_to_async
    def get_user_businesses(self):
        # Esta función obtiene los negocios de un usuario de forma asíncrona
        if hasattr(self.user, 'profile'):
            return list(self.user.profile.businesses.all())
        return []

    @database_sync_to_async
    def set_online_status(self, status):
        Profile.objects.update_or_create(user=self.user, defaults={'is_online': status})

# ==============================================================================
# CONSUMIDOR PARA LOS CHATS INDIVIDUALES
# ==============================================================================
class ChatConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.user = self.scope["user"]
        if not self.user.is_authenticated or not self.user.is_staff:
            await self.close()
            return
        
        self.room_name = self.scope['url_route']['kwargs'].get('user_id')
        if not self.room_name:
            await self.close()
            return
            
        self.room_group_name = f'chat_{self.room_name}'
        await self.channel_layer.group_add(self.room_group_name, self.channel_name)
        await self.accept()
        print(f"Agente '{self.user.username}' conectado a WebSocket para sala: {self.room_group_name}")

    async def disconnect(self, close_code):
        if hasattr(self, 'room_group_name'):
             await self.channel_layer.group_discard(self.room_group_name, self.channel_name)
        print(f"Agente '{self.user.username}' desconectado de sala de chat.")

    async def receive(self, text_data):
        data = json.loads(text_data)
        message = data['message']
        user_id = self.scope['url_route']['kwargs']['user_id']
        
        await self.save_message_and_send(user_id, message)

        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'chat_message',
                'message': message,
                'sender': 'HUMAN',
                'sender_name': self.user.first_name or self.user.username
            }
        )

    async def chat_message(self, event):
        await self.send(text_data=json.dumps({
            'message': event['message'],
            'sender': event['sender'],
            'sender_name': event.get('sender_name', 'Usuario'),
        }))
    
    @database_sync_to_async
    def save_message_and_send(self, user_id, message_text):
        try:
            conversation = Conversation.objects.get(user_id=user_id)
            Message.objects.create(
                conversation=conversation, sender='HUMAN', text=message_text
            )
            send_telegram_message(conversation.chat_id, message_text)
        except Conversation.DoesNotExist:
            print(f"Error en Consumer: No se encontró la conversación para el user_id {user_id}")