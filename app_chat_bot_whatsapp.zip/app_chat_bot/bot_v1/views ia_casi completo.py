# bots/views.py

import json
import requests
import random
from django.http import HttpResponse, Http404
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.template.loader import render_to_string
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync
from django.utils import timezone
from django.db.models import Q
from .models import Business, Conversation, Message, Profile

BOTPRESS_BASE_URL = "http://localhost:3000/api/v1/bots" 

# ==============================================================================
# VISTA PRINCIPAL DEL WEBHOOK
# ==============================================================================
@csrf_exempt
def telegram_webhook(request, token):
    if request.method != 'POST':
        return HttpResponse("Método no permitido.", status=405)

    try:
        business = get_object_or_404(Business, telegram_token=token, is_active=True)
        update = json.loads(request.body.decode('utf-8'))
        message_data = update.get('message', {})
        
        user_id = message_data['from']['id']
        chat_id = message_data['chat']['id']
        
        conversation = get_or_create_conversation(user_id, chat_id, message_data, business)
        
        if 'contact' in message_data:
            handle_contact_message(message_data, conversation)
        elif message_data.get('text'):
            handle_text_message(message_data, conversation)

    except Http404:
        print(f"Error: Mensaje recibido con un token desconocido o inactivo: {token}")
        return HttpResponse("Token no autorizado.", status=403)
    except (KeyError, json.JSONDecodeError):
        return HttpResponse("❌ Error procesando el mensaje.", status=400)

    return HttpResponse("OK")

# ==============================================================================
# FUNCIONES AUXILIARES PARA EL WEBHOOK (ACTUALIZADAS)
# ==============================================================================
def get_or_create_conversation(user_id, chat_id, message_data, business):
    user_first_name = message_data['from'].get('first_name', '')
    conversation, created = Conversation.objects.get_or_create(
        user_id=user_id,
        business=business,
        defaults={'chat_id': chat_id, 'user_first_name': user_first_name}
    )
    if not created and conversation.chat_id != chat_id:
        conversation.chat_id = chat_id
        conversation.save()
    return conversation

def handle_contact_message(message_data, conversation):
    phone_number = message_data['contact']['phone_number']
    conversation.phone_number = phone_number
    conversation.save()
    Message.objects.create(conversation=conversation, sender='USER', text=f"Contacto compartido: {phone_number}")
    
    response_text = "¡Gracias! Hemos guardado tu número."
    send_telegram_message(conversation.business.telegram_token, conversation.chat_id, response_text)
    Message.objects.create(conversation=conversation, sender='BOT', text=response_text)

def handle_text_message(message_data, conversation):
    user_message = message_data.get('text', '')
    Message.objects.create(conversation=conversation, sender='USER', text=user_message)

    if conversation.status != 'BOT':
        notify_agent_of_new_message(conversation, user_message)
        return

    palabras_clave = ['agente', 'humano', 'persona', 'ayuda']
    if any(palabra in user_message.lower() for palabra in palabras_clave):
        transfer_to_agent(conversation)
        return

    send_to_botpress_and_reply(conversation, user_message)

def notify_agent_of_new_message(conversation, user_message):
    channel_layer = get_channel_layer()
    group_name = f"business_{conversation.business.id}"
    async_to_sync(channel_layer.group_send)(
        group_name,
        {"type": "chat_message", "message": user_message, "sender": "USER", "sender_name": conversation.user_first_name}
    )
    print(f"📢 Notificación enviada a la sala: {group_name}")
    
def transfer_to_agent(conversation):
    if conversation.status != 'BOT':
        return 

    available_agents = User.objects.filter(
        is_staff=True, 
        is_active=True, 
        profile__is_online=True,
        profile__businesses=conversation.business
    ).order_by('profile__last_assignment_time')

    agent_to_assign = available_agents.first()
    
    if agent_to_assign:
        conversation.status = 'PENDING'
        conversation.assigned_agent = agent_to_assign
        conversation.save()
        agent_to_assign.profile.last_assignment_time = timezone.now()
        agent_to_assign.profile.save()
        response_text = f"¡Entendido! Te estoy transfiriendo. Serás atendido por {agent_to_assign.first_name or agent_to_assign.username}."
        print(f"🗣️ Conversación {conversation.id} transferida a {agent_to_assign.username} por ruleta.")
    else:
        response_text = "Lo siento, no hay agentes disponibles en este momento. Intenta más tarde."
    
    send_telegram_message(conversation.business.telegram_token, conversation.chat_id, response_text)
    Message.objects.create(conversation=conversation, sender='BOT', text=response_text)
    
    from .consumers import AgentStatusConsumer
    channel_layer = get_channel_layer()
    html_chat = render_to_string("bots/partials/pending_chat_item.html", {'conv': conversation})
    group_name = f"business_{conversation.business.id}"
    async_to_sync(channel_layer.group_send)(
        group_name,
        {"type": "new_pending_chat", "html": html_chat}
    )

def send_to_botpress_and_reply(conversation, user_message):
    business = conversation.business
    if not business.botpress_bot_id:
        print(f"Error: El negocio '{business.name}' no tiene un Botpress Bot ID configurado.")
        return

    converse_url = f"{BOTPRESS_BASE_URL}/{business.botpress_bot_id}/converse/{conversation.user_id}"
    
    try:
        botpress_response = requests.post(converse_url, json={"type": "text", "text": user_message})
        botpress_response.raise_for_status()
        bot_responses = botpress_response.json().get('responses', [])
    except requests.exceptions.RequestException as e:
        print(f"🚫 Error al contactar Botpress: {e}")
        send_telegram_message(business.telegram_token, conversation.chat_id, "⚠️ El bot no está disponible en este momento.")
        return

    for response in bot_responses:
        if response.get('type') == 'text':
            message_text = response.get('text', '')
            if message_text:
                send_telegram_message(business.telegram_token, conversation.chat_id, message_text)
                Message.objects.create(conversation=conversation, sender='BOT', text=message_text)

# --- FUNCIÓN DE ENVÍO REFACTORIZADA ---
def send_telegram_message(bot_token, chat_id, text, reply_markup=None):
    """
    Enviar un mensaje al usuario en Telegram USANDO EL TOKEN DEL NEGOCIO CORRECTO.
    """
    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    payload = {'chat_id': chat_id, 'text': text}
    if reply_markup:
        payload['reply_markup'] = reply_markup
    try:
        requests.post(url, json=payload).raise_for_status()
    except requests.exceptions.RequestException as e:
        print(f"❌ Error al enviar mensaje a Telegram (Token: {bot_token[:10]}...): {e}")

# ==============================================================================
# VISTAS PARA EL PANEL DE AGENTES (CON SEGURIDAD MEJORADA)
# ==============================================================================
@login_required
def live_chats_view(request):
    try:
        user_profile = request.user.profile
    except Profile.DoesNotExist:
        return HttpResponse("Tu usuario no tiene un perfil configurado.", status=403)

    if request.user.is_superuser:
        conversations_queryset = Conversation.objects.all()
        agents_queryset = User.objects.filter(is_staff=True)
    else:
        user_businesses = user_profile.businesses.all()
        conversations_queryset = Conversation.objects.filter(business__in=user_businesses)
        agents_queryset = User.objects.filter(is_staff=True, profile__businesses__in=user_businesses).distinct()

    pending_conversations_count = conversations_queryset.filter(status='PENDING').count()
    context = {
        'conversations': conversations_queryset.order_by('-last_message_time'),
        'agents': agents_queryset,
        'pending_count': pending_conversations_count,
    }
    return render(request, 'bots/live_chats.html', context)

@login_required
def conversation_detail_view(request, user_id):
    conversation = get_object_or_404(Conversation, user_id=user_id)
    
    # --- CHEQUEO DE SEGURIDAD MULTI-NEGOCIO ---
    if not request.user.is_superuser and conversation.business not in request.user.profile.businesses.all():
        return HttpResponse("No tienes permiso para ver este chat.", status=403)
        
    if request.method == 'POST':
        # ... (lógica del formulario de envío de mensaje del agente) ...

    messages = conversation.messages.all() 
    context = {'conversation': conversation, 'messages': messages}
    return render(request, 'bots/conversation_detail.html', context)

@login_required
def close_conversation_view(request, user_id):
    conversation = get_object_or_404(Conversation, user_id=user_id)
    # --- CHEQUEO DE SEGURIDAD ---
    if not request.user.is_superuser and conversation.business not in request.user.profile.businesses.all():
        return HttpResponse("No tienes permiso para esta acción.", status=403)
        
    conversation.status = 'BOT'
    conversation.assigned_agent = None
    conversation.save()
    notification_text = "Nuestro agente ha finalizado esta sesión. Vuelves a estar con el asistente virtual."
    send_telegram_message(conversation.business.telegram_token, conversation.chat_id, notification_text)
    Message.objects.create(conversation=conversation, sender='BOT', text=notification_text)
    return redirect('live_chats')

@login_required
def claim_conversation_view(request, user_id):
    from .consumers import AgentStatusConsumer
    conversation = get_object_or_404(Conversation, user_id=user_id)
    
    # --- CHEQUEO DE SEGURIDAD ---
    if not request.user.is_superuser and conversation.business not in request.user.profile.businesses.all():
        return HttpResponse("No puedes reclamar un chat de un negocio al que no perteneces.", status=403)
        
    if conversation.status == 'PENDING':
        conversation.status = 'HUMAN'
        conversation.assigned_agent = request.user
        conversation.save()
        
        # ... (Notificación por WebSocket) ...
        
        agent_name = request.user.first_name or request.user.username
        notification_text = f"¡Hola! Soy {agent_name} y te atenderé a partir de ahora."
        send_telegram_message(conversation.business.telegram_token, conversation.chat_id, notification_text)
        Message.objects.create(conversation=conversation, sender='HUMAN', text=notification_text)

    return redirect('conversation_detail', user_id=user_id)

@login_required
def reassign_conversation_view(request, user_id):
    if not hasattr(request.user, 'profile') or not request.user.profile.is_supervisor:
        return HttpResponse("No tienes permiso.", status=403)
        
    if request.method == 'POST':
        conversation = get_object_or_404(Conversation, user_id=user_id)
        # ... (lógica de reasignación) ...
    return redirect('live_chats')