# bots/models.py

from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver

# --- NUEVO MODELO PRINCIPAL ---
class Business(models.Model):
    """
    Representa a un cliente o negocio individual en la plataforma.
    Cada Business tiene su propia configuración de bot y sus propios agentes.
    """
    ASSIGNMENT_CHOICES = [
        ('CLAIM', 'Reclamar Primero'),
        ('ROULETTE', 'Ruleta Equitativa'),
    ]
    name = models.CharField(max_length=100, unique=True, help_text="Nombre del negocio o cliente")
    botpress_bot_id = models.CharField(max_length=50, blank=True, null=True, help_text="ID del Bot en Botpress")
    telegram_token = models.CharField(max_length=100, blank=True, null=True, unique=True, help_text="Token del Bot de Telegram")
    is_active = models.BooleanField(default=True, help_text="Desactiva el bot si el cliente no paga")
    assignment_strategy = models.CharField(max_length=10, choices=ASSIGNMENT_CHOICES, default='CLAIM')

    # --- CAMPOS DE TELEGRAM (Los dejamos por si acaso) ---
    telegram_token = models.CharField(max_length=100, blank=True, null=True, unique=True)

    # --- NUEVOS CAMPOS PARA WHATSAPP CLOUD API ---
    whatsapp_token = models.TextField(blank=True, null=True, help_text="Token de acceso permanente o temporal")
    whatsapp_phone_id = models.CharField(max_length=50, blank=True, null=True, help_text="ID del número de teléfono")
    whatsapp_verify_token = models.CharField(max_length=100, blank=True, null=True, unique=True, help_text="Token que tú inventas para verificar el webhook")

    def __str__(self):
        return self.name

# bots/models.py

# bots/models.py
class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    is_online = models.BooleanField(default=False)
    is_supervisor = models.BooleanField(default=False, help_text="Designa a este usuario como supervisor")
    businesses = models.ManyToManyField(Business, blank=True, related_name="agents")

    # --- NUEVO CAMPO ---
    last_assignment_time = models.DateTimeField(null=True, blank=True, help_text="Registra la última vez que se le asignó un chat a este agente.")

    def __str__(self):
        return f"Perfil de {self.user.username}"

# bots/models.py

class Conversation(models.Model):
    STATUS_CHOICES = [
        ('BOT', 'Controlado por el Bot'),
        ('HUMAN', 'Controlado por un Humano'),
        ('PENDING', 'Esperando por un Humano'),
    ]

    business = models.ForeignKey(Business, on_delete=models.CASCADE, related_name="conversations")
    
    # --- CAMBIO IMPORTANTE ---
    # Eliminamos 'unique=True' de aquí. Un usuario SÍ puede aparecer múltiples veces.
    user_id = models.BigIntegerField() 
    
    chat_id = models.BigIntegerField()
    user_first_name = models.CharField(max_length=255, blank=True, null=True)
    phone_number = models.CharField(max_length=20, blank=True, null=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='BOT')
    assigned_agent = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    notes = models.TextField(blank=True, null=True, help_text="Notas internas del agente.")
    start_time = models.DateTimeField(auto_now_add=True)
    last_message_time = models.DateTimeField(auto_now=True)

    class Meta:
        # --- NUEVA REGLA ---
        # Le decimos a la base de datos que la COMBINACIÓN de user_id y business debe ser única.
        constraints = [
            models.UniqueConstraint(fields=['user_id', 'business'], name='unique_user_per_business')
        ]

    def __str__(self):
        return f"Conversación con {self.user_first_name or 'Usuario'} para {self.business.name}"

class Message(models.Model):
    # ... (El modelo Message no necesita cambios) ...
    SENDER_CHOICES = [
        ('USER', 'Usuario'),
        ('BOT', 'Bot'),
        ('HUMAN', 'Agente Humano'),
    ]
    conversation = models.ForeignKey(Conversation, related_name='messages', on_delete=models.CASCADE)
    sender = models.CharField(max_length=10, choices=SENDER_CHOICES)
    text = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering = ['timestamp']
    def __str__(self):
        return f"De {self.sender}: '{self.text[:50]}...'"

# --- Las señales se quedan igual para crear el Profile automáticamente ---
@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        Profile.objects.create(user=instance)

@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    instance.profile.save()