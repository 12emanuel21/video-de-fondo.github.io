¡Entendido\! Quieres un solo documento unificado, como un tutorial de principio a fin, que explique todo el proceso que seguimos. Así tendrás una guía completa en un solo lugar.

Aquí tienes el resumen completo en un formato de texto simple, usando solo `**` para el énfasis, tal como pediste. Puedes copiar y pegar todo esto en un archivo `README.md`.

-----

### **Guía Completa de Configuración del Proyecto Chat Bot**

Este documento es la guía definitiva para configurar el entorno de desarrollo de este proyecto desde cero en una máquina con WSL (Subsistema de Windows para Linux). El objetivo es tener un entorno robusto, profesional y listo para empezar a programar.

-----

### **Parte 1: Configuración del Entorno de Desarrollo en WSL**

Estos son los pasos para preparar la máquina y el proyecto.

**1.1. Prerrequisitos del Sistema**

Primero, asegúrate de que tu sistema WSL (Ubuntu/Debian) tenga instalado el siguiente software. Puedes usar `sudo apt install <nombre_paquete>` para instalarlos.

  * **Python 3.12+** y las herramientas `pip` y `venv`.
  * **PostgreSQL Server** (la base de datos principal).
  * **Redis Server** (necesario para la comunicación en tiempo real con Django Channels).
  * **Git** (para el control de versiones).

**1.2. Entorno Virtual de Python**

Una vez clonado o creado el proyecto, el primer paso es aislar las dependencias de Python.

```bash
# Navega a la carpeta de tu proyecto
cd /ruta/a/tu/app_chat_bot

# Crea un entorno virtual llamado 'venvChatBot'
python3 -m venv venvChatBot

# Activa el entorno. Verás (venvChatBot) al inicio de tu línea de comandos.
source venvChatBot/bin/activate
```

**1.3. Dependencias de Python**

Todas las librerías de Python que necesita el proyecto están listadas en el archivo `requirements.txt`.

```bash
# Instala todas las dependencias de una vez
pip install -r requirements.txt
```

**1.4. Configuración de la Base de Datos PostgreSQL**

Django necesita un usuario y una base de datos específica para funcionar.

```bash
# 1. Accede a la consola de PostgreSQL como superusuario
sudo -u postgres psql

# 2. Dentro de psql, ejecuta estos comandos SQL para crear el usuario y la base de datos.
#    Cada comando debe terminar con un punto y coma (;).
CREATE USER evargas WITH PASSWORD '12Nele21' CREATEDB;
CREATE DATABASE project_chat_bots OWNER evargas;

# 3. Sal de la consola de psql
\q
```

**1.5. Variables de Entorno (El Archivo .env)**

Para mantener las contraseñas y claves secretas fuera del código, usamos un archivo `.env`. **Este archivo NUNCA debe subirse a GitHub.**

Crea un archivo llamado `.env` en la raíz del proyecto y añade el siguiente contenido.

```ini
SECRET_KEY='aqui_va_una_clave_secreta_larga_y_aleatoria_de_django'
DEBUG=True

DB_NAME='project_chat_bots'
DB_USER='evargas'
DB_PASSWORD='12Nele21'
DB_HOST=localhost
DB_PORT=5432

AGENT_KEYWORDS="agente,humano,persona,ayuda"
```

**1.6. Configuración Final de Django**

Con todo lo anterior listo, podemos decirle a Django que prepare la base de datos.

```bash
# Este comando crea todas las tablas que Django necesita en la base de datos que creamos.
python manage.py migrate

# Este comando crea un usuario administrador para poder entrar a http://127.0.0.1:8000/admin/
python manage.py createsuperuser
```

En este punto, **tu entorno de desarrollo local está 100% funcional**. Puedes iniciar el servidor con `python manage.py runserver` y empezar a programar.

-----

### **Parte 2: Configuración del Control de Versiones con Git y GitHub**

Estos son los pasos para guardar tu código y subirlo a un repositorio privado.

**2.1. Inicializar el Repositorio y Crear un `.gitignore`**

El archivo `.gitignore` le dice a Git qué archivos y carpetas debe ignorar.

```bash
# Inicializa un repositorio de Git en la carpeta del proyecto
git init

# Renombra la rama principal a 'main', que es el estándar actual
git branch -m main
```

Crea un archivo llamado `.gitignore` en la raíz del proyecto con este contenido para ignorar archivos sensibles y temporales:

```gitignore
venvChatBot/
.env
db.sqlite3
__pycache__/
*.pyc
```

**2.2. Guardar el Primer Cambio (Commit)**

Antes de hacer tu primer commit, debes decirle a Git quién eres. **Esto solo se hace una vez por máquina.**

```bash
git config --global user.name "Tu Nombre"
git config --global user.email "tu_correo@ejemplo.com"
```

Ahora sí, guarda todos tus archivos en el primer commit.

```bash
git add .
git commit -m "Configuración inicial del proyecto con Django y PostgreSQL"
```

**2.3. Conectar con GitHub y Subir el Código**

GitHub ya no permite usar contraseñas para subir código. Necesitas un **Token de Acceso Personal (PAT)**.

  * **Paso 1:** Ve a tu cuenta de GitHub -\> Settings -\> Developer settings -\> Personal access tokens -\> **Tokens (classic)**.
  * **Paso 2:** Genera un nuevo token "classic". Dale un nombre, una fecha de expiración (ej: 90 días) y asígnale el permiso (`scope`) llamado **`repo`**.
  * **Paso 3:** Copia el token que se genera. **Es la única vez que lo verás.**

Ahora, en tu terminal, conecta tu proyecto local con el repositorio que creaste en GitHub y sube el código.

```bash
# Reemplaza la URL con la de tu repositorio
git remote add origin https://github.com/12emanuel21/app_chat_bot.git

# Sube tu código. Te pedirá tu usuario y contraseña.
# En el campo de contraseña, PEGA el token que acabas de copiar.
git push -u origin main
```

-----

### **Parte 3: Simplificar la Autenticación con GitHub CLI**

Para no tener que pegar el token cada vez que expire, instalamos el **GitHub CLI (`gh`)**, que gestiona la autenticación por ti.

```bash
# 1. Instala la herramienta en WSL
sudo apt update
sudo apt install gh

# 2. Inicia sesión
gh auth login
```

Sigue los pasos del asistente: elige `HTTPS`, `Login with a web browser`, copia el código que te da la terminal y pégalo en la página de GitHub que se abre.

Una vez hecho esto, **nunca más te pedirá contraseña para hacer `git push` o `git pull`**. Si en el futuro la sesión expira (por ejemplo, en un año), solo tendrás que ejecutar `gh auth refresh`.