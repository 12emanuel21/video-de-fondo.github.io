from django import forms
from model import BroadcastTemplate

class BroadcastForm(forms.Form):
    template = forms.ModelChoiceField(
        queryset=BroadcastTemplate.objects.none(),
        label="Plantilla",
        required=True
    )
    recipients = forms.CharField(
        widget=forms.Textarea(attrs={
            'placeholder': 'Un número por línea, con código de país\n573001234567\n573107382726',
            'rows': 10
        }),
        label="Lista de destinatarios",
        required=True
    )

    def __init__(self, user, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if hasattr(user, 'profile'):
            businesses = user.profile.businesses.all()
            self.fields['template'].queryset = BroadcastTemplate.objects.filter(business__in=businesses)