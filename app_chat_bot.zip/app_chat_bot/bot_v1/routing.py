# bots/routing.py

from django.urls import re_path
from . import consumers

websocket_urlpatterns = [
    # USAR \w+ para aceptar números largos, letras, etc.
    re_path(r'^ws/conversation/(?P<user_id>\w+)/$', consumers.ChatConsumer.as_asgi()),
    
    re_path(r'^ws/agent_status/$', consumers.AgentStatusConsumer.as_asgi()),
]