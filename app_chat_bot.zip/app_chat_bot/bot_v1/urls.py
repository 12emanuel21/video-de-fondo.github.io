# bots/urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('webhook/<str:token>/', views.telegram_webhook, name='telegram_webhook'),
    path('webhook/whatsapp/<str:verify_token>/', views.whatsapp_webhook, name='whatsapp_webhook'), # Nueva ruta
    path('live_chats/', views.live_chats_view, name='live_chats'),
    path('conversation/<int:user_id>/', views.conversation_detail_view, name='conversation_detail'),
    path('conversation/<int:user_id>/claim/', views.claim_conversation_view, name='claim_conversation'),
    path('conversation/<int:user_id>/close/', views.close_conversation_view, name='close_conversation'),
    path('conversation/<int:user_id>/save_notes/', views.save_notes_view, name='save_notes'),
    path('conversation/<int:user_id>/reassign/', views.reassign_conversation_view, name='reassign_conversation'),
    path('dashboard/', views.dashboard_view, name='dashboard'),
    path('supervisor/', views.supervisor_dashboard_view, name='supervisor_dashboard'),
    path('conversation/<int:user_id>/force_close/', views.force_close_conversation_view, name='force_close_conversation'),
    path('conversation/<int:user_id>/upload/', views.upload_media_view, name='upload_media'),
    path('broadcast/test/', views.test_broadcast_view, name='test_broadcast'),
    path('broadcast/admin/', views.broadcast_admin_view, name='broadcast_admin'),
    path('broadcast/send/', views.broadcast_send_view, name='broadcast_send'),


]