# bots/consumers.py

import json
import aiohttp
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
from .models import Conversation, Message
from django.utils.module_loading import import_string

# ==============================================================================
# FUNCIONES AUXILIARES ASÍNCRONAS (fuera de las clases)
# ==============================================================================

@database_sync_to_async
def get_conversation_and_business(user_id):
    """Obtiene la conversación y su negocio de forma asíncrona."""
    conversation = Conversation.objects.get(user_id=int(user_id))
    return conversation, conversation.business

async def send_whatsapp_message_async(business, to_number, text_body):
    """Envía un mensaje de WhatsApp de forma asíncrona."""
    url = f"https://graph.facebook.com/v17.0/{business.whatsapp_phone_id}/messages"
    headers = {
        "Authorization": f"Bearer {business.whatsapp_token}",
        "Content-Type": "application/json",
    }
    data = {
        "messaging_product": "whatsapp",
        "to": to_number,
        "type": "text",
        "text": {"body": text_body},
    }

    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, headers=headers, json=data) as response:
                if response.status != 200:
                    error_text = await response.text()
                    print(f"❌ Error WhatsApp (async): {response.status} - {error_text}")
                else:
                    print(f"✅ WhatsApp enviado (async) a {to_number}")
    except Exception as e:
        print(f"❌ Excepción en send_whatsapp_message_async: {e}")

async def send_message_to_client_async(conversation, text):
    """Router asíncrono: solo WhatsApp por ahora."""
    business = await database_sync_to_async(lambda: conversation.business)()
    if business.whatsapp_token and business.whatsapp_phone_id:
        await send_whatsapp_message_async(business, str(conversation.user_id), text)
    elif business.telegram_token:
        print("⚠️ Telegram no es async aún. Considera migrar.")
    else:
        print(f"❌ Negocio sin credenciales: {business.name}")


# ==============================================================================
# CONSUMIDOR PARA EL ESTADO ONLINE/OFFLINE DE AGENTES
# ==============================================================================

class AgentStatusConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.user = self.scope["user"]
        if not self.user.is_authenticated or not self.user.is_staff:
            await self.close()
            return

        await self.accept()
        self.business_groups = []
        user_businesses = await self.get_user_businesses()
        for business in user_businesses:
            group_name = f"business_{business.id}"
            self.business_groups.append(group_name)
            await self.channel_layer.group_add(group_name, self.channel_name)
        await self.update_and_broadcast_status(True)
        print(f"PRESENCE: Agente '{self.user.username}' está ONLINE.")

    async def disconnect(self, close_code):
        if hasattr(self, 'user') and self.user.is_authenticated:
            await self.update_and_broadcast_status(False)
            if hasattr(self, 'business_groups'):
                for group_name in self.business_groups:
                    await self.channel_layer.group_discard(group_name, self.channel_name)
            print(f"PRESENCE: Agente '{self.user.username}' está OFFLINE.")

    async def agent_status_update(self, event):
        await self.send(text_data=json.dumps({
            'type': 'status_update',
            'user_id': event['user_id'],
            'is_online': event['is_online']
        }))

    async def new_pending_chat(self, event):
        await self.send(text_data=json.dumps({
            'type': 'new_pending_chat',
            'html': event['html']
        }))

    async def chat_claimed(self, event):
        await self.send(text_data=json.dumps({
            'type': 'chat_claimed',
            'user_id': event['user_id']
        }))

    async def update_and_broadcast_status(self, status):
        await self.set_online_status(status)
        if hasattr(self, 'business_groups'):
            for group_name in self.business_groups:
                await self.channel_layer.group_send(
                    group_name,
                    {
                        "type": "agent_status_update",
                        "user_id": self.user.id,
                        "is_online": status,
                    }
                )

    @database_sync_to_async
    def get_user_businesses(self):
        if hasattr(self.user, 'profile'):
            return list(self.user.profile.businesses.all())
        return []

    @database_sync_to_async
    def set_online_status(self, status):
        from .models import Profile
        Profile.objects.update_or_create(user=self.user, defaults={'is_online': status})


# ==============================================================================
# CONSUMIDOR PARA LOS CHATS INDIVIDUALES
# ==============================================================================

class ChatConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.user = self.scope["user"]
        if not self.user.is_authenticated or not self.user.is_staff:
            await self.close()
            return
        
        self.room_name = str(self.scope['url_route']['kwargs'].get('user_id'))
        if not self.room_name:
            await self.close()
            return
            
        self.room_group_name = f'chat_{self.room_name}'
        await self.channel_layer.group_add(self.room_group_name, self.channel_name)
        await self.accept()
        print(f"Agente '{self.user.username}' conectado a WebSocket para sala: {self.room_group_name}")

    async def disconnect(self, close_code):
        if hasattr(self, 'room_group_name'):
            await self.channel_layer.group_discard(self.room_group_name, self.channel_name)
        print(f"Agente '{self.user.username}' desconectado de sala de chat.")

    async def receive(self, text_data):
        data = json.loads(text_data)
        message = data['message']
        user_id = self.scope['url_route']['kwargs']['user_id']
        await self.save_message_and_send_async(user_id, message)

        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'chat_message',
                'message': message,
                'sender': 'HUMAN',
                'sender_name': self.user.first_name or self.user.username
            }
        )

    async def chat_message(self, event):
        await self.send(text_data=json.dumps({
            'message': event['message'],
            'sender': event['sender'],
            'sender_name': event.get('sender_name', 'Usuario'),
        }))
    
    async def save_message_and_send_async(self, user_id, message_text):
        try:
            conversation, business = await get_conversation_and_business(user_id)
            
            # Guardar en BD
            await database_sync_to_async(
                Message.objects.create
            )(conversation=conversation, sender='HUMAN', text=message_text)
            
            print("✅ Mensaje guardado en BD (async flow).")
            
            # Enviar al cliente
            await send_message_to_client_async(conversation, message_text)
            print("✅ Enviado a cliente vía WhatsApp (async).")
            
        except Conversation.DoesNotExist:
            print(f"❌ No se encontró la conversación para user_id: {user_id}")
        except Exception as e:
            print(f"❌ Error en save_message_and_send_async: {e}")