# bots/models.py

from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver

# --- NUEVO MODELO PRINCIPAL ---
class Business(models.Model):
    """
    Representa a un cliente o negocio individual en la plataforma.
    Cada Business tiene su propia configuración de bot y sus propios agentes.
    """
    ASSIGNMENT_CHOICES = [
        ('CLAIM', 'Reclamar Primero'),
        ('ROULETTE', 'Ruleta Equitativa'),
    ]
    name = models.CharField(max_length=100, unique=True, help_text="Nombre del negocio o cliente")
    botpress_bot_id = models.CharField(max_length=50, blank=True, null=True, help_text="ID del Bot en Botpress")
    telegram_token = models.CharField(max_length=100, blank=True, null=True, unique=True, help_text="Token del Bot de Telegram")
    is_active = models.BooleanField(default=True, help_text="Desactiva el bot si el cliente no paga")
    assignment_strategy = models.CharField(max_length=10, choices=ASSIGNMENT_CHOICES, default='CLAIM')

    # --- CAMPOS DE TELEGRAM (Los dejamos por si acaso) ---
    telegram_token = models.CharField(max_length=100, blank=True, null=True, unique=True)

    # --- NUEVOS CAMPOS PARA WHATSAPP CLOUD API ---
    whatsapp_token = models.TextField(blank=True, null=True, help_text="Token de acceso permanente o temporal")
    whatsapp_phone_id = models.CharField(max_length=50, blank=True, null=True, help_text="ID del número de teléfono")
    whatsapp_verify_token = models.CharField(max_length=100, blank=True, null=True, unique=True, help_text="Token que tú inventas para verificar el webhook")

    def __str__(self):
        return self.name
    
    def save(self, *args, **kwargs):
        # Limpia espacios al principio y final del token
        if self.whatsapp_token:
            self.whatsapp_token = self.whatsapp_token.strip()
        super().save(*args, **kwargs)

# bots/models.py

# bots/models.py
class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    is_online = models.BooleanField(default=False)
    is_supervisor = models.BooleanField(default=False, help_text="Designa a este usuario como supervisor")
    businesses = models.ManyToManyField(Business, blank=True, related_name="agents")

    # --- NUEVO CAMPO ---
    last_assignment_time = models.DateTimeField(null=True, blank=True, help_text="Registra la última vez que se le asignó un chat a este agente.")

    def __str__(self):
        return f"Perfil de {self.user.username}"

# bots/models.py

class Conversation(models.Model):
    STATUS_CHOICES = [
        ('BOT', 'Controlado por el Bot'),
        ('HUMAN', 'Controlado por un Humano'),
        ('PENDING', 'Esperando por un Humano'),
    ]

    business = models.ForeignKey(Business, on_delete=models.CASCADE, related_name="conversations")
    
    # --- CAMBIO IMPORTANTE ---
    # Eliminamos 'unique=True' de aquí. Un usuario SÍ puede aparecer múltiples veces.
    user_id = models.BigIntegerField() 
    
    chat_id = models.BigIntegerField()
    user_first_name = models.CharField(max_length=255, blank=True, null=True)
    phone_number = models.CharField(max_length=20, blank=True, null=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='BOT')
    assigned_agent = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    notes = models.TextField(blank=True, null=True, help_text="Notas internas del agente.")
    start_time = models.DateTimeField(auto_now_add=True)
    last_message_time = models.DateTimeField(auto_now=True)

    class Meta:
        # --- NUEVA REGLA ---
        # Le decimos a la base de datos que la COMBINACIÓN de user_id y business debe ser única.
        constraints = [
            models.UniqueConstraint(fields=['user_id', 'business'], name='unique_user_per_business')
        ]

    def __str__(self):
        return f"Conversación con {self.user_first_name or 'Usuario'} para {self.business.name}"

# bots/models.py

class Message(models.Model):
    SENDER_CHOICES = [
        ('USER', 'Usuario'),
        ('BOT', 'Bot'),
        ('HUMAN', 'Agente Humano'),
    ]
    # Nuevo: Tipos de mensaje
    TYPE_CHOICES = [
        ('text', 'Texto'),
        ('image', 'Imagen'),
        ('audio', 'Audio'),
        ('document', 'Documento'),
    ]

    conversation = models.ForeignKey(Conversation, related_name='messages', on_delete=models.CASCADE)
    sender = models.CharField(max_length=10, choices=SENDER_CHOICES)
    
    # Modificamos text para que pueda ser opcional (si solo envían una foto sin texto)
    text = models.TextField(blank=True, null=True) 
    
    # --- NUEVOS CAMPOS ---
    msg_type = models.CharField(max_length=10, choices=TYPE_CHOICES, default='text')
    media_file = models.FileField(upload_to='whatsapp_media/', blank=True, null=True)
    
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['timestamp']

    def __str__(self):
        return f"De {self.sender} ({self.msg_type}): '{self.text[:20]}...'"

# --- Las señales se quedan igual para crear el Profile automáticamente ---
@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        Profile.objects.create(user=instance)

@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    instance.profile.save()
    
    
    
class BroadcastMessage(models.Model):
    business = models.ForeignKey(Business, on_delete=models.CASCADE, related_name="broadcasts")
    recipient = models.CharField(max_length=20)  # Número de WhatsApp
    message_text = models.TextField()
    sent_at = models.DateTimeField(auto_now_add=True)
    responded = models.BooleanField(default=False)
    responded_at = models.DateTimeField(null=True, blank=True)
    delivery_status = models.CharField(
        max_length=20,
        choices=[
            ('pending', 'Pendiente'),
            ('delivered', 'Entregado'),
            ('read', 'Leído'),
            ('failed', 'Fallido'),
        ],
        default='pending'
    )

    def __str__(self):
        return f"Broadcast a {self.recipient} para {self.business.name}"
    class Meta:
        permissions = [
            ("can_send_broadcast", "Puede enviar mensajes masivos"),
        ]
    
class BroadcastTemplate(models.Model):
    name = models.CharField(max_length=100, help_text="Nombre descriptivo de la plantilla")
    message_text = models.TextField(help_text="Cuerpo del mensaje. Puedes usar {{nombre}} si quieres (opcional)")
    business = models.ForeignKey(Business, on_delete=models.CASCADE, related_name="broadcast_templates")
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name
    class Meta:
        permissions = [
            ("can_send_broadcast", "Puede enviar mensajes masivos"),
        ]