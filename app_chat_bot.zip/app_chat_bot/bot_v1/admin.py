# bots/admin.py
import requests
from django.contrib import messages
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.models import User
from .models import Business, Profile, Conversation, Message, BroadcastTemplate

def setup_webhook_action(modeladmin, request, queryset):
    """
    Esta función busca la URL de Ngrok y configura el webhook para
    todos los negocios seleccionados.
    """
    # 1. Intentar obtener la URL pública de Ngrok automáticamente
    # Ngrok expone una API local en el puerto 4040 que nos dice su URL actual
    ngrok_url = None
    try:
        response = requests.get("http://127.0.0.1:4040/api/tunnels", timeout=2)
        data = response.json()
        # Buscamos el túnel HTTPS
        for tunnel in data['tunnels']:
            if tunnel['proto'] == 'https':
                ngrok_url = tunnel['public_url']
                break
    except Exception as e:
        messages.error(request, f"❌ No se pudo detectar Ngrok automáticamente. Asegúrate de que esté corriendo. Error: {e}")
        return

    if not ngrok_url:
        messages.error(request, "❌ Ngrok está corriendo pero no se encontró un túnel HTTPS activo.")
        return

    # 2. Iterar sobre los negocios seleccionados y actualizar Telegram
    success_count = 0
    for business in queryset:
        if not business.telegram_token:
            messages.warning(request, f"⚠️ '{business.name}' no tiene token de Telegram. Omitido.")
            continue

        # Construimos la URL final: https://ngrok.../webhook/TOKEN/
        webhook_url = f"{ngrok_url}/webhook/{business.telegram_token}/"
        telegram_api = f"https://api.telegram.org/bot{business.telegram_token}/setWebhook?url={webhook_url}"

        try:
            res = requests.get(telegram_api, timeout=5)
            result = res.json()
            
            if result.get('ok'):
                success_count += 1
            else:
                error_desc = result.get('description', 'Error desconocido')
                messages.error(request, f"❌ Falló '{business.name}': {error_desc}")
        except Exception as e:
            messages.error(request, f"❌ Error de conexión para '{business.name}': {e}")

    if success_count > 0:
        messages.success(request, f"✅ ¡Éxito! Webhooks actualizados para {success_count} negocio(s) usando la URL: {ngrok_url}")

setup_webhook_action.short_description = "⚡ Actualizar Webhook de Telegram (Automático)"


# Define un 'inline' para poder editar el Profile dentro de la vista de User
class ProfileInline(admin.StackedInline):
    model = Profile
    can_delete = False
    verbose_name_plural = 'Perfiles'

# Define un nuevo User admin
class UserAdmin(BaseUserAdmin):
    inlines = (ProfileInline,)

# Vuelve a registrar el User admin con nuestra versión mejorada
admin.site.unregister(User.objects.model)
admin.site.register(User, UserAdmin)

# Registra el nuevo modelo Business
@admin.register(Business)
class BusinessAdmin(admin.ModelAdmin):
    list_display = ('name', 'botpress_bot_id', 'is_active', 'assignment_strategy')
    list_filter = ('is_active', 'assignment_strategy')
    search_fields = ('name',)
    
    # --- ¡ESTA ES LA LÍNEA QUE FALTABA! ---
    actions = [setup_webhook_action]

# Registra los otros modelos para verlos en el admin
@admin.register(Conversation)
class ConversationAdmin(admin.ModelAdmin):
    list_display = ('user_first_name', 'business', 'status', 'assigned_agent', 'last_message_time')
    list_filter = ('business', 'status')
    search_fields = ('user_first_name', 'user_id')

admin.site.register(Message)

@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'is_online')
    # ¡LA LÍNEA MÁGICA! Activa la doble ventana para el campo 'businesses'
    filter_horizontal = ('businesses',)
    
    

@admin.register(BroadcastTemplate)
class BroadcastTemplateAdmin(admin.ModelAdmin):
    list_display = ['name', 'business', 'created_at']
    list_filter = ['business']