# asgi.py - VERSIÓN CORREGIDA

import os
from django.core.asgi import get_asgi_application
from channels.routing import ProtocolTypeRouter, URLRouter
from channels.auth import AuthMiddlewareStack
# NO importes tu routing aquí arriba

# 1. Configurar el entorno de Django PRIMERO.
#    Esta línea le dice a Django dónde encontrar tu archivo de settings.
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'app_chat_bot.settings')

# 2. Cargar la aplicación HTTP de Django.
#    ¡Esta es la línea crítica que configura los settings!
django_asgi_app = get_asgi_application()

# 3. AHORA SÍ, importa tu routing (después de que Django esté listo).
from channels.routing import ProtocolTypeRouter, URLRouter
from channels.auth import AuthMiddlewareStack
import bot_v1.routing  # noqa: E402

# 4. Define el router principal que gestionará los diferentes protocolos.
application = ProtocolTypeRouter({
    "http": django_asgi_app,  # Usa la aplicación HTTP que ya cargamos
    "websocket": AuthMiddlewareStack(
        URLRouter(
            bot_v1.routing.websocket_urlpatterns
        )
    ),
})